__author__ = 'varribas'

## import simplification
# empty __init__.py:
#   from easyiceconfig import easyiceconfig as EasyIce
# new option:
#   import easyiceconfig as EasyIce
from .easyiceconfig import *

